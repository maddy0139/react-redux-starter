import { createStore, compose, applyMiddleware } from 'redux';
import {createLogger} from 'redux-logger';
import thunkMiddleware from 'redux-thunk';
import promiseMiddleware from 'redux-promise-middleware';
import rootReducer from '../reducers/rootReducer';

const logger = createLogger({
    collapsed:true
});
const Store = createStore(
    rootReducer,
    compose(applyMiddleware(thunkMiddleware,promiseMiddleware,logger))
);

export default Store;

