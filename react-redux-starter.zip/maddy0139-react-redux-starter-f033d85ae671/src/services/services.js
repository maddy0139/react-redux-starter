class Services{
    static getDummyData(){
        return new Promise((resolve,reject)=>{
            fetch('https://jsonplaceholder.typicode.com/todos/1')
            .then(response=>response.json())
            .then(data=>resolve(data));
        });
    }
}

export default Services;