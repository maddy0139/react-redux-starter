import React, { Component } from 'react';
import './App.css';
import Home from '../home/home';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Home/>
      </div>
    );
  }
}

export default App;
