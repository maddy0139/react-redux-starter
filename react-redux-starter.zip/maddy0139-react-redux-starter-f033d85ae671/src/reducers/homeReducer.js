import {handleActions} from 'redux-actions';
import { GET_DUMMY_DATA_PENDING, GET_DUMMY_DATA_FULFILLED, GET_DUMMY_DATA_REJECTED } from '../constants/actionTypes';

let initialState = {
    dummyData:{}
};

export default handleActions({
    [GET_DUMMY_DATA_PENDING]:(state,action)=>{
        return{
            ...state
        }
    },
    [GET_DUMMY_DATA_FULFILLED]:(state,action)=>{
        return{
            ...state,
            dummyData:action.payload
        }
    },
    [GET_DUMMY_DATA_REJECTED]:(state,action)=>{
        return{
            ...state
        }
    }
},initialState);
