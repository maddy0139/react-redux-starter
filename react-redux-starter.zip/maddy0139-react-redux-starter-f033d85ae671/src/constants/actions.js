import {createAction} from 'redux-actions';
import {GET_DUMMY_DATA} from './actionTypes';
import Services from '../services/services';

export const getDummyData = createAction(
    GET_DUMMY_DATA,
    ()=>Services.getDummyData()
)