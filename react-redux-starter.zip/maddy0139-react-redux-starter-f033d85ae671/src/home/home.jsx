import React from "react";
import { connect } from "react-redux";
import * as actions from "../constants/actions";

class Home extends React.Component {
  constructor(props) {
    super(props);
  }
  componentDidMount() {
    this.props.dispatch(actions.getDummyData());
  }
  render() {
    return (
      <div>
        <h1>Home Component</h1>
        <p>Getting data from 'https://jsonplaceholder.typicode.com/todos/1'</p>
        <p>id: {this.props.dummyData.id}</p>
        <p>title: {this.props.dummyData.title}</p>
        <p>user id: {this.props.dummyData.userId}</p>
      </div>
    );
  }
}
function mapStateToProps(state, ownProps) {
  return {
    dummyData: state.HomeState.dummyData
  };
}
export default connect(mapStateToProps)(Home);
