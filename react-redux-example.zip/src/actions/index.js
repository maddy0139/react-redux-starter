let userId = 0
export const saveUser = username => ({
    type: 'SAVE_USER',
    payload: {
        username,
        id: userId++
    }
})