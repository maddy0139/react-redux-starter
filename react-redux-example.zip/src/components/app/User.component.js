import React from 'react';
import {connect} from 'react-redux';
import {saveUser} from '../../actions';

class UserComponent extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            username: ''
        };

        this.handleInputChange = this.handleInputChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleInputChange(event) {
        const target = event.target;
        const name = target.name;
        this.setState({
            [name]: target.value
        });
    }

    handleSubmit() {
        this.props.dispatch(saveUser(this.state.username));
        this.setState({username: ''});
    }
    render(){
        const {users} = this.props;
        return(
            <div>
                {
                    users.map((user,index) => {
                        return(
                            <li>{user.username}</li>
                        );
                    })
                }
                <label>Username: </label>
                <input name='username' onChange={this.handleInputChange} value={this.state.username}></input><br />
                <button onClick={this.handleSubmit}>Save User</button>
            </div>
        );
    }
}

const mapStateToProps = (state) => ({
    users: state.userState.userInfo
});

export default connect(mapStateToProps)(UserComponent);
