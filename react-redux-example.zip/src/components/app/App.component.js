import React from 'react';
import UserComponent from './User.component';

export default class AppComponent extends React.Component {
    render(){
        return(
            <UserComponent />
        );
    }
}