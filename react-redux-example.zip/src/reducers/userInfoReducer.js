const initialState = {
    userInfo: []
};
const userInfoReducer = (state = initialState, action) => {
    const {userInfo} = state;
    let newState;
    switch (action.type) {
      case 'SAVE_USER':
        userInfo.push(action.payload);
        newState = {
            ...state,
            userInfo
        };
        break;
      default:
        return newState = state;
    }
    return newState;
  }
  
  export default userInfoReducer;